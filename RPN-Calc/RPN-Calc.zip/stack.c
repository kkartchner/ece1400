#include "stack.h"

int contents [STACK_SIZE];
int top = 0;

/********************************************************************************************
* make_empty: Makes the stack empty by setting the top "open slot" equal to 0
*********************************************************************************************/
void make_empty (void)
{
	top = 0;
}

/********************************************************************************************
* is_empty: Returns true if the stack is empty (top equals 0) or false if it is not 
*********************************************************************************************/
bool is_empty (void)
{
	return top == 0;
}

/********************************************************************************************
* is_full: Returns true if the stack is full (top equals STACK_SIZE) or false if it is not 
*********************************************************************************************/
bool is_full (void)
{
	return top == STACK_SIZE;
}

/*************************************************************************************************************************
* push: First checks to see if the stack is full by calling the is_full function. If it is full, the stack_overflow	  
* function is called. If it isn't full, the open "top slot" located in the contents array is set to equal the argument
* passed into i. top is then incremented so the "open slot" is moved up.
**************************************************************************************************************************/	
void push (int i)
{
	if (is_full()) {
		stack_overflow();
	} else {
		contents [top++] = i;
	}
}

/*************************************************************************************************************************
* pop: First checks to see if the stack is empty by calling the is_empty function. If it is empty, 
* the stack_underflow function is called. Otherwise top is decremented and the value at the top of the stack is returned.
**************************************************************************************************************************/
int pop (void)
{
	if (is_empty()) {
		stack_underflow();
	} else {
		return contents [--top];
	}
}

/********************************************************************************************
* stack_overflow: Prints overflow message then terminates the program. 
*********************************************************************************************/
void stack_overflow()
{
	printf("\nExpression is too complex");
	exit(2);
}

/********************************************************************************************
* stack_underflow: Prints underflow message then terminates the program.
*********************************************************************************************/
void stack_underflow()
{
	printf("\nNot enough operands in expression");
	exit(3);
}
