#include "stack.h"

/* Generate operation functions from macro */
STACK_OPERATION(add, +);
STACK_OPERATION(subtract, -);
STACK_OPERATION(multiply, *);
STACK_OPERATION(divide, /);

/*********************************************************************************************
* main: Asks the user to input an RPN expression and then calculates and displays the result. 
**********************************************************************************************
* Psuedocode																				  
*																							  
* Begin                                                                                       
* Define "cur_char" as char                                                                   
* Print program instructions                                                                  
* Loop until the program is terminated                                                        
*		Scan for current char and store to cur_char                                           
*		If cur_char is a digit between 0 and 9                                                
*			Push the converted int value onto the stack                                       
*		Else                                                                                  
*			If cur_char is a space                                                            
*				Skip it by not doing anything							
*			Else
*				If cur_char is an operator
*					Call the corresponding operator function
*
*					If cur_char is an equals sign
*						Print message and value of expression
*						Clear the stack
*						Print message about entering another expression
*					End If
*				Else
*					Terminate the program
*				End If
*			End If					
*		End If
*	End Loop
* End
*****************************************************************************************/


int main()
{	// Begin
	char cur_char;													// Define "cur_char" as char
	
	printf("Welcome to RPN-Calc! \nEnter an RPN expression: ");		// Print program instructions
	
	for (;;){														// Loop until the program is terminated
		scanf (" %c", &cur_char);									// 		Scan for current char and store to cur_char
		if ('0' <= cur_char && cur_char <= '9'){					// 		If cur_char is a digit between 0 and 9
			push ((int) (cur_char - '0'));							// 			Push the converted int value onto the stack
		} else {													// 		Else
			switch (cur_char){										// 			If cur_char is a space
				case ' ': break;									// 				Skip it by not doing anything														
				case '+': add_stack(); break;						//			Else
				case '-': subtract_stack(); break;					// 				If cur_char is an operator
				case '/': divide_stack(); break;					// 					Call the corresponding operator function
				case '*': multiply_stack(); break;					
				case '=': 											//					If cur_char is an equals sign
					printf("Value of expression: %d\n", pop());		//						Print message and value of expression
					make_empty();									//						Clear the stack
					printf("Enter another RPN expression (or a letter to exit): ");	//		Print message about entering another expression
					break;											// 					End If
																	//				Else
				default: exit(1); break;							//					Terminate the program
																	//				End If
			}														// 			End If					
		}															// 		End If
	}																//	End Loop
	return 0;
}	// End