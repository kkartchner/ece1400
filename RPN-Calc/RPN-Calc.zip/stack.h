#ifndef STACK_H
#define STACK_H

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#define STACK_SIZE 100
#define STACK_OPERATION(name, operand)	\
void name##_stack ()				 	\
{										\
	int first = pop();					\
	push(pop() operand first);			\
}

/* Function Prototypes */
void make_empty (void);
bool is_empty (void);
bool is_full (void);
void push (int i);
int pop (void);
void stack_overflow(void);
void stack_underflow(void);
#endif